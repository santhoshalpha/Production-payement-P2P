"""P2P payment service package."""
